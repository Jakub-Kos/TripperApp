﻿using System.Windows;

namespace TripPlanner.Wpf.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow() => InitializeComponent();
        
    }
}
